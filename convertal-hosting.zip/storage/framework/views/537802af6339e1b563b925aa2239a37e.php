<?php $__env->startSection('title', 'Форматы — Convertal'); ?>
<?php $__env->startSection('description', 'Все конвертации Convertal: PDF, DOC, DOCX, JPG, JPEG и PNG.'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mx-auto max-w-6xl px-4 py-12">
        <p class="text-sm font-semibold text-brand">Форматы</p>
        <h1 class="mt-2 text-4xl font-extrabold tracking-tight">Что можно конвертировать</h1>
        <p class="mt-4 max-w-2xl text-lg leading-7 text-muted">Документы переводятся через LibreOffice, изображения — без пережатия лишний раз. Выберите пару и загрузите файл.</p>

        <div class="mt-10 grid gap-8">
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section>
                    <h2 class="text-2xl font-extrabold"><?php echo e($group['label']); ?></h2>
                    <div class="mt-4 grid gap-3 sm:grid-cols-2">
                        <?php $__currentLoopData = $group['links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($link['url']); ?>" class="rounded-3xl border border-line bg-white p-5 hover:border-brand dark:border-slate-800 dark:bg-slate-900">
                                <span class="text-lg font-extrabold"><?php echo e($link['label']); ?></span>
                                <span class="mt-2 block text-sm leading-6 text-muted"><?php echo e($link['text']); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /app/resources/views/formats/index.blade.php ENDPATH**/ ?>